let leiteColetado = 0;
let queijosFeitos = 0;
let fase = 1; // 1: Coletar leite, 2: Fazer queijo, 3: Entregar no mercado
let vacas = [];
let leites = [];
let mercado;

function setup() {
  createCanvas(600, 400);
  // Cria 5 vacas em posições aleatórias
  for (let i = 0; i < 5; i++) {
    vacas.push({
      x: random(50, width - 50),
      y: random(50, height - 50),
      tamanho: 50
    });
  }
  // Define a posição do mercado (aparece na fase 3)
  mercado = { x: width - 100, y: height / 2, tamanho: 80 };
}

function draw() {
  background(220);
  
  if (fase === 1) {
    // FASE 1: COLETAR LEITE
    textSize(24);
    fill(0);
    text("Fase 1: Clique nas vacas 🐄 para coletar leite 🥛", 20, 30);
    text(`Leite coletado: ${leiteColetado}/3`, 20, 60);
    
    // Desenha as vacas
    for (let vaca of vacas) {
      textSize(vaca.tamanho);
      text("🐄", vaca.x, vaca.y);
    }
    
    // Verifica se coletou leite suficiente
    if (leiteColetado >= 3) {
      fase = 2;
      leites = []; // Reseta os leites na tela
    }
    
  } else if (fase === 2) {
    // FASE 2: FAZER QUEIJO (arrastar 3 leites para o centro)
    textSize(24);
    fill(0);
    text("Fase 2: Arraste 3 leites 🥛🥛🥛 para fazer queijo 🧀", 20, 30);
    text(`Leites usados: ${leites.length}/3`, 20, 60);
    
    // Desenha os leites coletados (arrastáveis)
    for (let leite of leites) {
      textSize(40);
      text("🥛", leite.x, leite.y);
    }
    
    // Área de produção de queijo (centro)
    fill(200);
    rect(width / 2 - 50, height / 2 - 50, 100, 100);
    textSize(20);
    fill(0);
    text("SOLTE AQUI", width / 2 - 40, height / 2);
    
    // Verifica se 3 leites foram soltos no centro
    if (leites.length >= 3) {
      let todosNoCentro = true;
      for (let leite of leites) {
        if (dist(leite.x, leite.y, width / 2, height / 2) > 60) {
          todosNoCentro = false;
          break;
        }
      }
      if (todosNoCentro) {
        fase = 3;
        queijosFeitos++;
      }
    }
    
  } else if (fase === 3) {
    // FASE 3: ENTREGAR QUEIJO NO MERCADO
    textSize(24);
    fill(0);
    text("Fase 3: Arraste o queijo 🧀 até o mercado 🏪", 20, 30);
    
    // Desenha o mercado
    textSize(mercado.tamanho);
    text("🏪", mercado.x, mercado.y);
    
    // Desenha o queijo (arrastável)
    textSize(40);
    text("🧀", mouseX, mouseY);
    
    // Verifica se o queijo foi entregue
    if (dist(mouseX, mouseY, mercado.x, mercado.y) < 50 && mouseIsPressed) {
      fase = 1; // Volta para a fase 1
      leiteColetado = 0; // Reseta o leite
    }
  }
}

function mousePressed() {
  if (fase === 1) {
    // Verifica se clicou em uma vaca
    for (let vaca of vacas) {
      if (dist(mouseX, mouseY, vaca.x, vaca.y) < 30) {
        leiteColetado++;
        // Faz a vaca "pular" (muda de posição)
        vaca.x = random(50, width - 50);
        vaca.y = random(50, height - 50);
      }
    }
  } else if (fase === 2 && leites.length < 3) {
    // Adiciona um leite arrastável
    leites.push({ x: mouseX, y: mouseY });
  }
}